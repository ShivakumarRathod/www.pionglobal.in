const product = require('../model/product');
const { updateOne, create, deleteOne } = require('../model/users');
const { ObjectId } = require('mongoose');

const _get = async (req, res) => {
    try {
        let results = await product.find(req.params.id).toArray();
        if (results) {
            res.send(results);
        } else {
            res.send('No data');
        }
    } catch (error) {
        return error;
    }
};

const _create = async (req, res) => {
    try {
        let results = await create(req.body);
        if (results) {
            return res.send(results);
        } else {
            return res.send('Unable to create product');
        }

    } catch (error) {
        throw error;
    }
};
const _update = async (req, res) => {
    try {
        let results = await updateOne({ _id: ObjectId(req.param.id) }, { $set: { param: req.body } });
        if (results) {
            return res.send(results);
        } else {
            return res.send('Unable to create product');
        }

    } catch (error) {
        throw error;
    }
};
const _delete = async (req, res) => {
    try {
        let results = await deleteOne({ _id: ObjectId(req.param.id) });
        if (results) {
            return res.send(results);
        } else {
            return res.send('Unable to create product');
        }

    } catch (error) {
        throw error;
    }
};

module.exports = {
    _get,
    _create,
    _update,
    _delete
}