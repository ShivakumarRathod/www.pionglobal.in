const mongoose = require('mongoose');
const { URI } = process.env;

exports.connect = () => {
    mongoose.connect(URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }).then(() => {
        console.log('Connected Successfully');
    })
        .catch((error) => {
            console.log('database connetion error');
            console.log(error);
            process.exit(1);
        })
}