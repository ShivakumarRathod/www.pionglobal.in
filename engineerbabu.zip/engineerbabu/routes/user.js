
const express = require('express').Router;
const router = express();

const registerUser = require('../controller/users');

router.post('/register', registerUser.register);
router.post('/login', registerUser.login);

module.exports = router;