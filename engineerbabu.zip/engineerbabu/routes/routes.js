const express = require('express').Router;
const router = express();


const auth = require('../middleware/auth');

router.use('/users', require('./user'));
router.use('/products', require('./product'));

module.exports = router;

