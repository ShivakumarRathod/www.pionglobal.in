
const express = require('express').Router;
const router = express();

const product = require('../controller/product');

router.get('/:id?', product._get);
router.post('/', product._create);
router.put('/:id', product._update);
router.delete('/:id', product._delete);

module.exports = router;